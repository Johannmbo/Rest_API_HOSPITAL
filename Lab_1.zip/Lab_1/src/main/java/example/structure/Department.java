package example.structure;

import java.util.List;

public class Department {

    private String name;
    private int employeeCount;
    private List<String> rooms;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setEmployeeCount(int employeeCount) {
        this.employeeCount = employeeCount;
    }

    public void setRooms(List<String> rooms) {
        this.rooms = rooms;
    }

    public int getEmployeeCount() {
        return employeeCount;
    }

    public List<String> getRooms() {
        return rooms;
    }
}
