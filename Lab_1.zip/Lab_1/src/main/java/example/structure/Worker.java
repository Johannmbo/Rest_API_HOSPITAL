package example.structure;

import java.util.List;

public class Worker {

    private String fullName;
    private String address;
    private List<String> departments;
    private String birthDate;
    private String position;

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setDepartments(List<String> departments) {
        this.departments = departments;
    }

    public void setBirthDate(String birthDate) {
        this.birthDate = birthDate;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAddress() {
        return address;
    }

    public List<String> getDepartments() {
        return departments;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public String getPosition() {
        return position;
    }
}
