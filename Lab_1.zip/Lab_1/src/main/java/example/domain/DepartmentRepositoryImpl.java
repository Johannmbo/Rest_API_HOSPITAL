package example.domain;

import example.IStructure.DepartmentRepository;
import example.structure.Department;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Component
@Repository
public class DepartmentRepositoryImpl implements DepartmentRepository {
    private List<Department> departments = new ArrayList<>();

    public DepartmentRepositoryImpl(){}

    @Override
    public void create(Department department) {
        departments.add(department);
    }

    @Override
    public void update(Department department) {
        Department existingDepartment = findByName(department.getName());
        if (existingDepartment != null) {
            existingDepartment.setName(department.getName());
            existingDepartment.setEmployeeCount(department.getEmployeeCount());
            existingDepartment.setRooms(department.getRooms());
        }
    }

    @Override
    public void delete(String name) {
        for (int i = 0; i < departments.size(); i++) {
            Department department = departments.get(i);
            if (department.getName().equals(name)) {
                departments.remove(i);
                break;
            }
        }
    }
    @Override
    public Department findByName(String name) {
        for (Department department : departments) {
            if (department.getName().equals(name)) {
                return department;
            }
        }
        return null;
    }
    public List<Department> getDepartments() {
        return departments;
    }
}


