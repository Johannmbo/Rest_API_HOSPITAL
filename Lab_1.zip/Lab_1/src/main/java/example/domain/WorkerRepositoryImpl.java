package example.domain;
import example.IStructure.WorkerRepository;
import example.structure.Worker;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import java.util.ArrayList;
import java.util.List;

@Component
@Repository
public class WorkerRepositoryImpl implements WorkerRepository {

    private List<Worker> employees = new ArrayList<>();
    public WorkerRepositoryImpl(){}
    @Override
    public void create(Worker employee) {
        employees.add(employee);
    }

    @Override
    public void update(Worker employee) {
        Worker existingEmployee = findByNameAndPosition(employee.getFullName(),employee.getPosition());
        if (existingEmployee != null) {
            existingEmployee.setAddress(employee.getAddress());
            existingEmployee.setDepartments(employee.getDepartments());
            existingEmployee.setBirthDate(employee.getBirthDate());
        }
    }

    @Override
    public void delete(String name,String position) {
        for (Worker employee : employees) {
            if (employee.getFullName().equals(name) && employee.getPosition().equals(position)) {
                employees.remove(employee);
                break;
            }
        }
    }
    @Override
    public Worker findByNameAndPosition(String fullName,String position) {
        for (Worker employee : employees) {
            if (employee.getFullName().equals(fullName) && employee.getPosition().equals(position)) {
                return employee;
            }
        }
        return null;
    }
    public List<Worker> getEmployees() {
        return employees;
    }
}
