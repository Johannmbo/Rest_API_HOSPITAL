package example.JM_Services;

import example.ApplicationServices.DepartmentService;
import example.ApplicationServices.WorkerService;
import example.structure.Department;
import example.structure.Worker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Component("mainLayer")
public class MainLayer {

    private WorkerService employeeService;
    private DepartmentService departmentService;
    private Scanner scanner = new Scanner(System.in);
    @Autowired
    public MainLayer(WorkerService employeeService, DepartmentService departmentService) {
        this.employeeService = employeeService;
        this.departmentService = departmentService;
    }
    public MainLayer(){}
    public void work() {
        while (true) {
            System.out.println("Выберите действие:");
            System.out.println("1) Добавить сотрудника");
            System.out.println("2) Обновить информацию о сотруднике");
            System.out.println("3) Удалить сотрудника");
            System.out.println("4) Найти сотрудника");
            System.out.println("5) Добавить отдел");
            System.out.println("6) Обновить информацию об отделе");
            System.out.println("7) Удалить отдел");
            System.out.println("8) Найти отдел");
            System.out.println("0) Выход");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    updateEmployee();
                    break;
                case 3:
                    deleteEmployee();
                    break;
                case 4:
                    findEmployee();
                    break;
                case 5:
                    addDepartment();
                    break;
                case 6:
                    updateDepartment();
                    break;
                case 7:
                    deleteDepartment();
                    break;
                case 8:
                    findDepartment();
                    break;
                case 0:
                    System.out.println("Завершение работы.");
                    return;
                default:
                    System.out.println("Некорректный выбор.");
            }
        }
    }

    private void addEmployee() {
        Worker employee = new Worker();

        System.out.println("Введите ФИО сотрудника:");
        employee.setFullName(scanner.next());
        scanner.nextLine();
        System.out.println("Введите адрес проживания сотрудника:");
        employee.setAddress(scanner.nextLine());

        System.out.println("Введите количество отделов:");
        int countDepartments = scanner.nextInt();
        List<String> departments = new ArrayList<>();
        for(int i=0;i<countDepartments;i++) {
            departments.add(scanner.next());
        }
        employee.setDepartments(departments);
        scanner.nextLine();

        System.out.println("Введите дату рождения сотрудника:");
        employee.setBirthDate(scanner.nextLine());

        System.out.println("Введите должность сотрудника:");
        employee.setPosition(scanner.nextLine());

        employeeService.createEmployee(employee);
        System.out.println("Сотрудник успешно добавлен.");
    }

    private void updateEmployee() {
        scanner.nextLine();
        System.out.println("Введите имя сотрудника для обновления: ");
        String name = scanner.next();
        scanner.nextLine();
        System.out.println("Вводите позицию сотрудника: ");
        String position = scanner.next();
        scanner.nextLine();

        Worker existingEmployee = employeeService.findEmployeeByNameAndPosition(name,position);
        if(existingEmployee == null) {
            System.out.println("Сотрудник не найден");
        }else{
            System.out.println("Введите новые данные для обновления:");

            System.out.println("Введите адрес проживания сотрудника:");
            existingEmployee.setAddress(scanner.nextLine());

            System.out.println("Введите количество отделов:");
            int countDepartments = scanner.nextInt();
            System.out.println("Вводите отделы: ");
            List<String> departments = new ArrayList<>();
            for(int i=0;i<countDepartments;i++) {
                departments.add(scanner.next());
            }
            existingEmployee.setDepartments(departments);
            scanner.nextLine();
            System.out.println("Введите дату рождения сотрудника:");
            existingEmployee.setBirthDate(scanner.nextLine());

            System.out.println("Введите должность сотрудника:");
            existingEmployee.setPosition(scanner.nextLine());

            employeeService.updateEmployee(existingEmployee);
            System.out.println("Информация о сотруднике успешно обновлена.");
        }

    }

    private void deleteEmployee() {
        System.out.println("Введите имя сотрудника для удаления:");
        String name = scanner.next();
        scanner.nextLine();
        System.out.println("Введите позицию сотрудника: ");
        String position = scanner.next();

        Worker existingEmployee = employeeService.findEmployeeByNameAndPosition(name,position);
        if(existingEmployee == null) {
            System.out.println("Сотрудник не найден!");
        }else{
            employeeService.deleteEmployee(name,position);
            System.out.println("Сотрудник успешно удален.");
        }
    }

    private void findEmployee() {
        System.out.println("Введите ФИО сотрудника:");
        String name = scanner.next();
        scanner.nextLine();
        System.out.println("Введите позицию сотрудника: ");
        String position = scanner.next();
        Worker existingEmployee = employeeService.findEmployeeByNameAndPosition(name, position);
        if(existingEmployee == null) {
            System.out.println("Работник не найден!");
        }else {
            printInfoEmployee(existingEmployee);
        }
    }

    private void addDepartment() {
        Department department = new Department();
        scanner.nextLine();
        System.out.println("Введите название отдела:");
        department.setName(scanner.next());

        System.out.println("Введите количество сотрудников в отделе:");
        int employeeCount = scanner.nextInt();
        department.setEmployeeCount(employeeCount);
        scanner.nextLine();

        System.out.println("Введите количество комнат: ");
        int countRooms = scanner.nextInt();
        System.out.println("Введите список комнат, в которых размещается отдел:");
        List<String> rooms = new ArrayList<>();
        for(int i=0;i<countRooms;i++) {
            rooms.add(scanner.next());
        }
        department.setRooms(rooms);

        departmentService.createDepartment(department);
        System.out.println("Отдел успешно добавлен.");
    }

    private void updateDepartment() {
        System.out.println("Введите название отдела для обновления:");
        String name = scanner.next();
//        scanner.nextLine();

        Department existingDepartment = departmentService.findDepartmentByName(name);
        if(existingDepartment == null) {
            System.out.println("Отдел не найден");
        }else {
            System.out.println("Введите новые данные для обновления:");

            System.out.println("Введите количество сотрудников в отделе:");
            int employeeCount = scanner.nextInt();
            existingDepartment.setEmployeeCount(employeeCount);
            scanner.nextLine();

            System.out.println("Введите количество комнат: ");
            int countRooms = scanner.nextInt();
            System.out.println("Введите список комнат, в которых размещается отдел:");
            List<String> rooms = new ArrayList<>();
            for(int i=0;i<countRooms;i++) {
                rooms.add(scanner.next());
            }
            existingDepartment.setRooms(rooms);

            departmentService.updateDepartment(existingDepartment);
            System.out.println("Информация об отделе успешно обновлена.");
        }

    }

    private void deleteDepartment() {
        System.out.println("Введите название отдела для удаления:");
        String name = scanner.next();
        scanner.nextLine();

        Department existingDepartment = departmentService.findDepartmentByName(name);
        if(existingDepartment == null) {
            System.out.println("Отдел не найден!");
        }else{
            departmentService.deleteDepartment(name);
            System.out.println("Отдел успешно удален.");
        }
    }

    private void findDepartment() {
        System.out.println("Введите название отдела для поиска:");
        String name = scanner.next();

        Department existingDepartment = departmentService.findDepartmentByName(name);
        if(existingDepartment == null) {
            System.out.println("Отдел не найден!");
        }else {
            printInfoDepartment(existingDepartment);
        }
    }
    public void printInfoEmployee(Worker employee) {
        System.out.println("Фио: "+employee.getFullName());
        System.out.println("Адресс: "+employee.getAddress());
        System.out.println("Дата рождения: "+employee.getBirthDate());
        System.out.println("Должность: "+employee.getPosition());
        System.out.println("Отделы: "+employee.getDepartments());
    }
    public void printInfoDepartment(Department department) {
        System.out.println("Название: "+department.getName());
        System.out.println("Список комнат: "+department.getRooms());
        System.out.println("Количество сотрудников: "+department.getEmployeeCount());
    }
}
