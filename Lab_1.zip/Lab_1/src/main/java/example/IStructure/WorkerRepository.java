package example.IStructure;
import example.structure.Worker;

public interface WorkerRepository {
    void create(Worker employee);

    void update(Worker employee);

    void delete(String fullName, String position);

    Worker findByNameAndPosition(String fullName, String position);
}
