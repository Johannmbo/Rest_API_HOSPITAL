package example.IStructure;


import example.structure.Department;

public interface DepartmentRepository {
    void create(Department department);

    void update(Department department);

    void delete(String name);

    Department findByName(String name);
}
