package example.ApplicationServices;


import example.IStructure.WorkerRepository;
import example.structure.Worker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Scope("singleton")
public class WorkerService {
    private WorkerRepository employeeRepository;
    @Autowired
    public WorkerService(WorkerRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    public WorkerService() {}
    @Transactional
    public void createEmployee(Worker employee) {
        employeeRepository.create(employee);
    }

    @Transactional
    public void updateEmployee(Worker employee) {
        employeeRepository.update(employee);
    }

    @Transactional
    public void deleteEmployee(String fullName, String position) {
        employeeRepository.delete(fullName, position);
    }
    @Transactional
    public Worker findEmployeeByNameAndPosition(String fullName, String position) {
        return employeeRepository.findByNameAndPosition(fullName, position);
    }
}
