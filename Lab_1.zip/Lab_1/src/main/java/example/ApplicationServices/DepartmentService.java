package example.ApplicationServices;
import example.IStructure.DepartmentRepository;
import example.structure.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


@Service
@Scope("singleton")
public class DepartmentService {
    private DepartmentRepository departmentRepository;
    @Autowired
    public DepartmentService(DepartmentRepository departmentRepository) {
        this.departmentRepository = departmentRepository;
    }
    public DepartmentService() {}
    @Transactional
    public void createDepartment(Department department) {
        departmentRepository.create(department);
    }
    @Transactional
    public void updateDepartment(Department department) {
        departmentRepository.update(department);
    }
    @Transactional
    public void deleteDepartment(String name) {
        departmentRepository.delete(name);
    }
    @Transactional
    public Department findDepartmentByName(String name) {
        return departmentRepository.findByName(name);
    }

}
